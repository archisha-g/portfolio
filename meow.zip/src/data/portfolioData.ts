import { Project, ExperienceItem, AwardItem, SkillCategory, EducationInfo } from '../types';

export const PERSONAL_INFO = {
  name: 'ARCHISHA GHANSHANI',
  eyebrow: 'COMPUTER SCIENCE • ARTIFICIAL INTELLIGENCE • SOFTWARE',
  tagline: 'I build software at the intersection of engineering, AI, and real-world problems.',
  bio: 'Computer Science Engineering graduate specializing in Artificial Intelligence, with experience across software development, AI/ML, technical product development, and team leadership.',
  about: `I am a Computer Science Engineering graduate specializing in Artificial Intelligence, with hands-on experience in software development, AI/ML, and technical product development.

I've worked across frontend, full-stack, and mobile development, and have led the development of a mobile application from scratch as a team lead.

My work spans compiler design, NLP, cybersecurity, computer vision, and AI-powered applications. I've also competed in and won multiple national hackathons and have research experience in artificial intelligence.

I enjoy solving complex technical problems and building practical, scalable solutions that combine strong engineering fundamentals with AI.`,
  status: {
    state: 'CURRENTLY',
    activity: 'BUILDING + LEARNING',
    location: 'MEERUT, INDIA',
    timezone: 'Asia/Kolkata',
  },
  ticker: ['SOFTWARE', 'AI', 'PRODUCT', 'RESEARCH', 'SYSTEMS', 'COMPILERS'],
  profileStrip: [
    { label: 'Education', value: 'B.Tech. CSE, Artificial Intelligence' },
    { label: 'Experience', value: 'Software • AI/ML • Product' },
    { label: 'Location', value: 'Meerut, India' },
    { label: 'Languages', value: 'English • Hindi' },
  ],
  contacts: {
    email: 'archishaghanshani@gmail.com',
    phone: '+91-7895203180',
    phoneRaw: '+917895203180',
    linkedin: 'https://www.linkedin.com/in/archisha-ghanshani-a49620252/',
    github: 'https://github.com/archisha-g',
  },
};

export const PROJECTS_DATA: Project[] = [
  {
    id: 'neuroscript',
    number: '01',
    name: 'NeuroScript',
    subtitle: 'A programming language and compiler designed around AI and natural language workflows.',
    description:
      'Developed a custom programming language and compiler with an intuitive high-level syntax for AI and natural language processing workflows. Built the complete compilation pipeline from scratch, including lexical analysis, parsing, semantic analysis, and Three-Address Code generation. Developed a FastAPI backend and interactive web-based IDE for writing, compiling, and executing NeuroScript programs.',
    technologies: ['Python', 'NLP', 'Compiler Design', 'FastAPI', 'JavaScript'],
    liveUrl: 'https://neuroscript-live.onrender.com/',
    isFeatured: true,
    pipelineStages: [
      'SOURCE CODE',
      'LEXICAL ANALYSIS',
      'PARSING (AST)',
      'SEMANTIC ANALYSIS',
      '3-ADDRESS CODE (3AC)',
      'EXECUTION ENGINE',
    ],
    codeSample: `// Sample NeuroScript AI Workflow
pipeline TextClassifier {
  input text: String
  model = load("transformer/nlp-core")
  
  transform token_stream = tokenize(text, clean: true)
  prediction = model.classify(token_stream)
  
  emit prediction.confidence > 0.85 ? prediction.label : "uncertain"
}`,
    details: {
      overview:
        'NeuroScript addresses the friction between standard procedural languages and specialized AI / NLP model orchestration by introducing first-class syntax constructs for data preprocessing, token streaming, and model graph evaluation.',
      architecture: [
        'Custom Lexer with regular expression token stream generator',
        'Recursive Descent Parser generating an Abstract Syntax Tree (AST)',
        'Type checking & Scope resolution in Semantic Analysis phase',
        'Intermediate Representation via Three-Address Code (3AC) quadruples',
        'FastAPI asynchronous server with sandboxed execution runner',
        'Monaco-powered Web IDE frontend for interactive compilation diagnostics',
      ],
      outcomes: [
        'End-to-end operational compilation pipeline built from fundamental computer science principles',
        'Integrated web IDE allowing developers to test syntax and inspect compiler intermediate representations in real-time',
      ],
    },
  },
  {
    id: 'sentinel',
    number: '02',
    name: 'Sentinel',
    subtitle: 'AI-powered threat detection and response system.',
    description:
      'Developed an AI-powered threat detection and response system designed to identify, analyze, and respond to potential cybersecurity threats. Integrated the Google Gemini API to analyze security events, generate contextual threat assessments, and provide recommended responses.',
    technologies: ['Python', 'AI/ML', 'Google Gemini API'],
    liveUrl: 'https://sena-drishti-frontend.onrender.com/',
    isFeatured: true,
    threatFlow: [
      'EVENT INGESTION',
      'THREAT ANALYSIS',
      'RISK ASSESSMENT',
      'RECOMMENDED RESPONSE',
    ],
    details: {
      overview:
        'Sentinel ingests raw cybersecurity telemetry and authentication events, classifies anomalies against attack vectors, and uses Google Gemini to generate human-interpretable severity ratings with prescriptive mitigation steps.',
      architecture: [
        'Real-time event parsing and anomaly threshold classification',
        'Prompt-engineered Google Gemini API context pipeline for zero-day heuristics',
        'Dynamic risk scoring matrix calculating impact vs exploitability',
        'Automated incident triage dashboard with live alert feeds',
      ],
      outcomes: [
        'Accelerated incident triage and reduced threat evaluation latency',
        'Actionable remediation suggestions generated in natural language for security operators',
      ],
    },
  },
  {
    id: 'brain-tumour-detection',
    number: '03',
    name: 'Brain Tumour Detection',
    subtitle: 'Deep learning medical image classification.',
    description:
      'Developed a deep learning-based medical image classification system for detecting brain tumors from medical scans using convolutional neural networks and transfer learning.',
    technologies: ['Python', 'TensorFlow', 'EfficientNetB0', 'Computer Vision'],
    details: {
      overview:
        'A transfer-learning convolutional pipeline built using EfficientNetB0 to classify MRI brain scans, applying data augmentation and feature map extraction to achieve accurate diagnostic classification.',
      architecture: [
        'MRI scan preprocessing, normalization, and contrast enhancement',
        'EfficientNetB0 backbone fine-tuned for multi-class tumor classification',
        'Validation protocols with confusion matrix and ROC-AUC evaluation',
      ],
      outcomes: [
        'High-accuracy medical image classification utilizing transfer learning',
        'Robust performance across varied scan resolutions and contrast settings',
      ],
    },
  },
  {
    id: 'image-deblurring',
    number: '04',
    name: 'Image Deblurring',
    subtitle: 'Computer vision restoration system.',
    description:
      'Developed an image restoration system using computer vision and deep learning techniques to reduce blur and improve image quality.',
    technologies: ['Python', 'OpenCV', 'Deep Learning'],
    details: {
      overview:
        'An image restoration framework leveraging OpenCV filtering alongside deep convolutional restoration architectures to remove motion blur, defocus, and noise artifacts.',
      architecture: [
        'Kernel estimation and edge-preserving filtering via OpenCV',
        'Deep reconstruction network trained on blurred-sharp image pairs',
        'PSNR and SSIM metric tracking for reconstruction quality validation',
      ],
      outcomes: [
        'Restored degraded images with noticeable sharpening of fine structural details',
        'Optimized pipeline capable of fast processing on edge hardware',
      ],
    },
  },
  {
    id: 'hate-speech-detection',
    number: '05',
    name: 'Hate Speech Detection',
    subtitle: 'NLP text classification pipeline.',
    description:
      'Developed a natural language processing system for detecting and classifying hate speech in text using machine learning and text classification techniques.',
    technologies: ['Python', 'NLP', 'Machine Learning', 'scikit-learn'],
    details: {
      overview:
        'An NLP pipeline for identifying toxic, abusive, and hate speech across unstructured textual datasets, employing lexical normalization, TF-IDF vectorization, and ensemble classifiers.',
      architecture: [
        'Tokenization, lemmatization, stop-word removal, and n-gram feature extraction',
        'scikit-learn classification models with hyperparameter tuning',
        'Class imbalance mitigation and threshold calibration',
      ],
      outcomes: [
        'Reliable classification of toxic text patterns with high precision and recall',
        'Lightweight deployment footprint suitable for real-time comment moderation',
      ],
    },
  },
  {
    id: 'fooddukaan',
    number: '06',
    name: 'FoodDukaan',
    subtitle: 'Full-stack food ordering platform.',
    description:
      'Developed a full-stack food ordering web application using the MERN stack, implementing frontend interfaces, backend APIs, database integration, and core ordering workflows.',
    technologies: ['MongoDB', 'Express.js', 'React', 'Node.js'],
    details: {
      overview:
        'A complete digital ordering system providing end-to-end user journeys from menu discovery to cart management, checkout authentication, and order status tracking.',
      architecture: [
        'Modular React frontend with component-based state management',
        'Express.js RESTful API endpoints with JWT authentication and middleware validation',
        'MongoDB document schemas for products, users, cart sessions, and orders',
      ],
      outcomes: [
        'Production-ready full-stack architecture with smooth responsive UI',
        'Robust transaction management and database query optimization',
      ],
    },
  },
];

export const EXPERIENCES_DATA: ExperienceItem[] = [
  {
    id: 'exp-1',
    number: '01',
    role: 'Technical Operations Manager',
    company: 'U W and Associates',
    location: 'Meerut, India',
    period: 'June 2026 — Present',
    description:
      'Manage technology-driven operational workflows across business processes, combining software, data, and business operations to improve efficiency and decision-making. Digitize and streamline operational processes across inventory, procurement, sales, accounting, and reporting. Analyze business data and operational records to improve process visibility and support data-driven decisions. Coordinate technology and process improvements across day-to-day business operations.',
    skillsHighlight: ['Process Digitization', 'Workflow Automation', 'Data Analysis', 'Operational Strategy'],
  },
  {
    id: 'exp-2',
    number: '02',
    role: 'Mobile Application Developer & Team Lead',
    company: 'Fix Dukaan',
    period: 'January 2025 — August 2025',
    description:
      "Led the development team in building Fix Dukaan's mobile application from scratch, taking the product from initial requirements and architecture through development, testing, and refinement. Developed the cross-platform application using React Native, integrated backend APIs and database services, coordinated development tasks, and guided the team through implementation, debugging, and feature development.",
    skillsHighlight: ['React Native', 'Team Leadership', 'API Integration', 'Mobile Architecture', 'Agile Delivery'],
  },
  {
    id: 'exp-3',
    number: '03',
    role: 'Full Stack Developer Intern',
    company: 'TBI-GEU University Program',
    period: 'November 2024 — January 2025',
    description:
      'Developed full-stack web applications using the MERN stack across frontend, backend, and database layers. Built and integrated RESTful APIs, implemented application functionality, worked with database systems, and developed responsive interfaces connected to backend services.',
    skillsHighlight: ['MERN Stack', 'RESTful APIs', 'MongoDB', 'Responsive Design'],
  },
  {
    id: 'exp-4',
    number: '04',
    role: 'Front End Developer Intern',
    company: "Tyson's Legal Allies",
    period: 'March 2024 — April 2024',
    description:
      'Developed responsive and user-friendly web interfaces using HTML, CSS, and JavaScript. Translated design requirements into functional and visually consistent web experiences while improving responsiveness, usability, and cross-device compatibility.',
    skillsHighlight: ['HTML5 / CSS3', 'JavaScript', 'Cross-Device Usability', 'UI Engineering'],
  },
];

export const AWARDS_DATA: AwardItem[] = [
  {
    id: 'award-1',
    year: '2026',
    title: 'Top 5 Women in Tech Medal',
    description: 'Awarded in recognition of achievement and contribution in technology.',
    badge: 'MEDAL',
  },
  {
    id: 'award-2',
    year: '2026',
    title: 'Outstanding Placement Award',
    description: 'Received in recognition of exceptional performance and achievement during the placement process.',
    badge: 'AWARD',
  },
  {
    id: 'award-3',
    year: '2026',
    title: 'Provisionally Accepted Research Paper — IEEE ICAITPR 2026',
    description:
      'Research paper provisionally accepted at IEEE ICAITPR 2026, recognizing research work in artificial intelligence and technology.',
    badge: 'RESEARCH',
  },
  {
    id: 'award-4',
    year: '2025',
    title: 'Winner — QubitX National Hackathon',
    organization: 'QubitX',
    description: 'Secured 1st place among 400+ participating teams.',
    badge: '1st',
  },
  {
    id: 'award-5',
    year: '2025',
    title: 'Winner — Hackaccino 3.0',
    organization: 'Bennett University',
    description: 'Secured 1st place through the development and presentation of a technical solution.',
    badge: '1st',
  },
  {
    id: 'award-6',
    year: '2025',
    title: 'First Overall — GNA Hackathon 3.0',
    organization: 'GNA University',
    description: 'Secured 1st position overall.',
    badge: '1st',
  },
  {
    id: 'award-7',
    year: '2025',
    title: '2nd Position — KRIYETA 4.0',
    organization: 'IEEE',
    description: 'Secured 2nd position in an IEEE-organized technical competition.',
    badge: '2nd',
  },
  {
    id: 'award-8',
    year: '2025',
    title: '3rd Position — Graph-E-Thon 2.0',
    organization: 'Graph-E-Thon',
    description: 'Secured 3rd position through the development and presentation of a technical solution.',
    badge: '3rd',
  },
];

export const SKILLS_DATA: SkillCategory[] = [
  {
    category: 'Languages',
    skills: ['Python', 'Java', 'C/C++', 'JavaScript', 'TypeScript', 'SQL'],
  },
  {
    category: 'Web & Application Development',
    skills: ['React', 'React Native', 'Node.js', 'Express.js', 'MERN', 'FastAPI'],
  },
  {
    category: 'AI / ML',
    skills: ['TensorFlow', 'PyTorch', 'scikit-learn', 'OpenCV', 'NLP', 'Computer Vision', 'EfficientNet'],
  },
  {
    category: 'Data & Tools',
    skills: ['MongoDB', 'PostgreSQL', 'pandas', 'NumPy', 'Git'],
  },
];

export const EDUCATION_DATA: EducationInfo = {
  institution: 'Graphic Era University',
  degree: 'Bachelor of Technology',
  specialization: 'Computer Science Engineering, Artificial Intelligence',
  period: 'September 2022 — June 2026',
};
