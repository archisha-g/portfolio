import React, { useState } from 'react';
import { AWARDS_DATA } from '../data/portfolioData';
import { Award, Sparkles, BookOpen } from 'lucide-react';

export const Recognition: React.FC = () => {
  const [hoveredAwardId, setHoveredAwardId] = useState<string | null>(null);

  // Group awards by year
  const years = Array.from(new Set(AWARDS_DATA.map((a) => a.year))).sort((a, b) => Number(b) - Number(a));

  const getBadgeIcon = (badge: string) => {
    switch (badge) {
      case 'RESEARCH':
        return <BookOpen size={12} aria-hidden="true" />;
      case 'MEDAL':
      case 'AWARD':
        return <Sparkles size={12} aria-hidden="true" />;
      default:
        return <Award size={12} aria-hidden="true" />;
    }
  };

  return (
    <section className="section-wrapper recognition-section" id="recognition" aria-labelledby="recognition-heading">
      <div className="container">
        <div className="section-header-row">
          <div>
            <span className="section-tag">05 / HONORS</span>
            <h2 id="recognition-heading" className="section-title">
              Recognition
            </h2>
          </div>
          <p className="section-intro">
            National hackathon championships, academic honors, technical competitions, and peer-reviewed research.
          </p>
        </div>

        <div className="recognition-list-wrap">
          {years.map((year) => {
            const yearAwards = AWARDS_DATA.filter((a) => a.year === year);
            return (
              <div key={year} className="recognition-year-group">
                <div className="recognition-year-aside font-mono">
                  <span className="year-sticky">{year}</span>
                </div>

                <div className="recognition-items-col">
                  {yearAwards.map((item) => {
                    const isHovered = hoveredAwardId === item.id;
                    return (
                      <div
                        key={item.id}
                        className={`recognition-item ${isHovered ? 'hovered' : ''}`}
                        onMouseEnter={() => setHoveredAwardId(item.id)}
                        onMouseLeave={() => setHoveredAwardId(null)}
                      >
                        <div className="recognition-main">
                          <div className="recognition-title-row">
                            <h3 className="recognition-title">{item.title}</h3>
                            {/* Hover Badge Indicator */}
                            <span className={`recognition-badge-tag ${item.badge.toLowerCase()}`}>
                              {getBadgeIcon(item.badge)}
                              <span>{item.badge}</span>
                            </span>
                          </div>
                          <p className="recognition-desc">{item.description}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
